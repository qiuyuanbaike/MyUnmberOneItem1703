package com.myunmbertwoitem1703;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class OneTurnActivity extends AppCompatActivity implements View.OnClickListener {


    private Spinner spinner_item_h, spinner_item_m;
    private ArrayAdapter<String> adapter_m, adapter_h;
    private Button sure_Button;
    private EditText content_edit;

    private ImageView
            imageView_pic_01, imageView_pic_02,
            imageView_pic_03, imageView_pic_04,
            imageView_pic_05, imageView_pic_06,
            imageView_pic_07, imageView_pic_08,
            imageView_pic_09;


    public String spinner_m[] = {
            "00", "5", "10", "15", "20", "25"
            , "30", "35", "40", "45", "50",
            "55"};
    private String spinner_h[] = {
            "00", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "10",
            "11", "12", "13", "14", "15",
            "16", "17", "18", "19", "20",
            "21", "22", "23"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_turn);
        initialUI();
        setImageViewOnClick();
        setSpinnerList();

    }

    //往spinner添加数组
    private void setSpinnerList() {
        adapter_m = new ArrayAdapter<String>(this, R.layout.text, spinner_m);
        adapter_h = new ArrayAdapter<String>(this, R.layout.text, spinner_h);
        spinner_item_m.setAdapter(adapter_m);
        spinner_item_h.setAdapter(adapter_h);
    }


    //初始化控件
    private void initialUI() {
        spinner_item_h = (Spinner) findViewById(R.id.item_sponner_H);
        spinner_item_m = (Spinner) findViewById(R.id.item_sponner_M);

        sure_Button = (Button) findViewById(R.id.sure_buttonId);
        content_edit = (EditText) findViewById(R.id.content_editId);

        imageView_pic_01 = (ImageView) findViewById(R.id.pic_image_01);
        imageView_pic_02 = (ImageView) findViewById(R.id.pic_image_02);
        imageView_pic_03 = (ImageView) findViewById(R.id.pic_image_03);
        imageView_pic_04 = (ImageView) findViewById(R.id.pic_image_04);
        imageView_pic_05 = (ImageView) findViewById(R.id.pic_image_05);
        imageView_pic_06 = (ImageView) findViewById(R.id.pic_image_06);
        imageView_pic_07 = (ImageView) findViewById(R.id.pic_image_07);
        imageView_pic_08 = (ImageView) findViewById(R.id.pic_image_08);
        imageView_pic_09 = (ImageView) findViewById(R.id.pic_image_09);


    }

    //点击ImageView添加本地数据图片
    private void clickAddPic() {
        Intent intent = new Intent(Intent.ACTION_PICK, null);
        intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*");
        startActivityForResult(intent, 1);
        startActivityForResult(intent, 2);
        startActivityForResult(intent, 3);
        startActivityForResult(intent, 4);
        startActivityForResult(intent, 5);
        startActivityForResult(intent, 6);
        startActivityForResult(intent, 7);
        startActivityForResult(intent, 8);
        startActivityForResult(intent, 9);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_01.setImageURI(data.getData());

            }

        } else if (requestCode == 2 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_02.setImageURI(data.getData());

            }


        } else if (requestCode == 3 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_03.setImageURI(data.getData());

            }


        } else if (requestCode == 4 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_04.setImageURI(data.getData());

            }


        } else if (requestCode == 5 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_05.setImageURI(data.getData());

            }


        } else if (requestCode == 6 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_06.setImageURI(data.getData());

            }


        } else if (requestCode == 7 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_07.setImageURI(data.getData());

            }


        } else if (requestCode == 8 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_08.setImageURI(data.getData());

            }


        } else if (requestCode == 9 && resultCode == RESULT_OK) {
            if (data != null) {
                imageView_pic_09.setImageURI(data.getData());

            }


        }

        super.onActivityResult(requestCode, resultCode, data);
    }


    //imageView点击监听事件
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.pic_image_01:
                clickAddPic();
                break;
            case R.id.pic_image_02:
                clickAddPic();
                break;
            case R.id.pic_image_03:
                clickAddPic();
                break;
            case R.id.pic_image_04:
                clickAddPic();
                break;
            case R.id.pic_image_05:
                clickAddPic();
                break;
            case R.id.pic_image_06:
                clickAddPic();
                break;
            case R.id.pic_image_07:
                clickAddPic();
                break;
            case R.id.pic_image_08:
                clickAddPic();
                break;
            case R.id.pic_image_09:
                clickAddPic();
                break;
            case R.id.sure_buttonId:
                String content = content_edit.getText().toString();
                if (!TextUtils.isEmpty(content)) {
                    Toast.makeText(this, "提交成功！", Toast.LENGTH_SHORT).show();
                    setTransmit();
                    //清空文本
                    content_edit.setText("");
                } else {
                    Toast.makeText(this, "内容不能为空！", Toast.LENGTH_SHORT).show();

                }
        }
    }


    //获取EditText的内容用Intent提交给另外一个Activity
    private void setTransmit() {
        Intent intent = new Intent(this, StoreContent.class);
        //传递文本内容
        intent.putExtra("str", content_edit.getText().toString());

        //传递图片
        imageView_pic_01.setDrawingCacheEnabled(true);
        imageView_pic_02.setDrawingCacheEnabled(true);
        imageView_pic_03.setDrawingCacheEnabled(true);
        imageView_pic_04.setDrawingCacheEnabled(true);
        imageView_pic_05.setDrawingCacheEnabled(true);
        imageView_pic_06.setDrawingCacheEnabled(true);
        imageView_pic_07.setDrawingCacheEnabled(true);
        imageView_pic_08.setDrawingCacheEnabled(true);
        imageView_pic_09.setDrawingCacheEnabled(true);

        Bitmap bitmap02 = Bitmap.createBitmap(imageView_pic_02.getDrawingCache());
        Bitmap bitmap01 = Bitmap.createBitmap(imageView_pic_01.getDrawingCache());
        Bitmap bitmap03 = Bitmap.createBitmap(imageView_pic_03.getDrawingCache());
        Bitmap bitmap04 = Bitmap.createBitmap(imageView_pic_04.getDrawingCache());
        Bitmap bitmap05 = Bitmap.createBitmap(imageView_pic_05.getDrawingCache());
        Bitmap bitmap06 = Bitmap.createBitmap(imageView_pic_06.getDrawingCache());
        Bitmap bitmap07 = Bitmap.createBitmap(imageView_pic_07.getDrawingCache());
        Bitmap bitmap08 = Bitmap.createBitmap(imageView_pic_08.getDrawingCache());
        Bitmap bitmap09 = Bitmap.createBitmap(imageView_pic_09.getDrawingCache());

        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ByteArrayOutputStream bos2 = new ByteArrayOutputStream();
        ByteArrayOutputStream bos3 = new ByteArrayOutputStream();
        ByteArrayOutputStream bos4 = new ByteArrayOutputStream();
        ByteArrayOutputStream bos5 = new ByteArrayOutputStream();
        ByteArrayOutputStream bos6 = new ByteArrayOutputStream();
        ByteArrayOutputStream bos7 = new ByteArrayOutputStream();
        ByteArrayOutputStream bos8 = new ByteArrayOutputStream();
        ByteArrayOutputStream bos9 = new ByteArrayOutputStream();

        bitmap01.compress(Bitmap.CompressFormat.PNG, 100, bos);
        bitmap02.compress(Bitmap.CompressFormat.PNG, 100, bos2);
        bitmap03.compress(Bitmap.CompressFormat.PNG, 100, bos3);
        bitmap04.compress(Bitmap.CompressFormat.PNG, 100, bos4);
        bitmap05.compress(Bitmap.CompressFormat.PNG, 100, bos5);
        bitmap06.compress(Bitmap.CompressFormat.PNG, 100, bos6);
        bitmap07.compress(Bitmap.CompressFormat.PNG, 100, bos7);
        bitmap08.compress(Bitmap.CompressFormat.PNG, 100, bos8);
        bitmap09.compress(Bitmap.CompressFormat.PNG, 100, bos9);

        byte[] b = bos.toByteArray();
        byte[] b2 = bos2.toByteArray();
        byte[] b3 = bos3.toByteArray();
        byte[] b4 = bos4.toByteArray();
        byte[] b5 = bos5.toByteArray();
        byte[] b6 = bos6.toByteArray();
        byte[] b7 = bos7.toByteArray();
        byte[] b8 = bos8.toByteArray();
        byte[] b9 = bos9.toByteArray();

        intent.putExtra("pic", b);
        intent.putExtra("pic2", b2);
        intent.putExtra("pic3", b3);
        intent.putExtra("pic4", b4);
        intent.putExtra("pic5", b5);
        intent.putExtra("pic6", b6);
        intent.putExtra("pic7", b7);
        intent.putExtra("pic8", b8);
        intent.putExtra("pic9", b9);

        imageView_pic_01.setDrawingCacheEnabled(false);
        imageView_pic_02.setDrawingCacheEnabled(false);
        imageView_pic_03.setDrawingCacheEnabled(false);
        imageView_pic_04.setDrawingCacheEnabled(false);
        imageView_pic_05.setDrawingCacheEnabled(false);
        imageView_pic_06.setDrawingCacheEnabled(false);
        imageView_pic_07.setDrawingCacheEnabled(false);
        imageView_pic_08.setDrawingCacheEnabled(false);
        imageView_pic_09.setDrawingCacheEnabled(false);
        startActivity(intent);
    }

    //为控件绑定监听事件
    private void setImageViewOnClick() {
        sure_Button.setOnClickListener(this);
        imageView_pic_01.setOnClickListener(this);
        imageView_pic_02.setOnClickListener(this);
        imageView_pic_03.setOnClickListener(this);
        imageView_pic_04.setOnClickListener(this);
        imageView_pic_05.setOnClickListener(this);
        imageView_pic_06.setOnClickListener(this);
        imageView_pic_07.setOnClickListener(this);
        imageView_pic_08.setOnClickListener(this);
        imageView_pic_09.setOnClickListener(this);

    }

}
